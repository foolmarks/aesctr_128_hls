#ifndef _AES128_DEFS_
#define _AES128_DEFS_

#include "ap_int.h"

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;


/*-------------------------------------------
  DEFINES
-------------------------------------------*/

// sum of NONCE_BITS + COUNT_BITS must be 128
#define COUNT_BITS 32
#define NONCE_BITS 128 - COUNT_BITS



/*-------------------------------------------
  TYPES
-------------------------------------------*/

typedef ap_uint<4>   word4;
typedef ap_uint<8>   word8;
typedef ap_uint<32>  word32;
typedef ap_uint<96>  word96;
typedef ap_uint<128> word128;



// AXI streaming
template<int D>
struct ap_axiu{
	ap_uint<D> data;
    ap_uint<1> last;

};


 
/*-------------------------------------------
  FUNCTION PROTOTYPES
-------------------------------------------*/

word128 subBytes(word128 stateIn);
word32  subWord(word32 stateIn);
word8   sBoxValue_16(int i, word8 index);
word8   sBoxValue_4(int i, word8 index);


word128 shiftRows(word128 stateIn);
word32  rotWord(word32 stateIn);
word32  rCon(word4 index);
word128 nonceCount(word128 init_vect, ap_uint<1> last);
word128 encMixCols(word128 stateIn);
word128 keyExpEngine(word4 rConAddr, word128 keyState);
word128 aes_ecb128(word128 key, word128 stateIn);

word8   gfmult2(word8 I);
word8   gfmult3(word8 I);

// top level function
void aes_ctr128_axis(ap_axiu<384> &stateIn, ap_axiu<128> &stateOut);



#endif


  
