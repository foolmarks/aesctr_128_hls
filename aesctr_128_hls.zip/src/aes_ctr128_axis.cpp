/*-----------------------------------------------------------------
  File: aes_ctr128.cpp

  The top level function for the complete AES-128 CTR mode
  encryptor/decryptor, including key expansion.
  
  This version has AXI Streaming interfaces.

  stateIn_TDATA[127:0]     - input data
  stateIn_TDATA[255:128]   - key
  stateIn_TDATA[383:256]   - initialisation vector

------------------------------------------------------------------*/


#include "aes128_ctr.h"



void aes_ctr128_axis(ap_axiu<384> &stateIn, ap_axiu<128> &stateOut){

	#pragma HLS INTERFACE axis register both depth=1 port=stateOut
	#pragma HLS INTERFACE axis register both depth=1 port=stateIn
	#pragma HLS INTERFACE ap_ctrl_none port=return


   word128 ecbOut;
   word128 nonceCntOut;

   stateOut.last = stateIn.last;

   // Nonce & counter
   nonceCntOut = nonceCount(stateIn.data.range(383,256), stateIn.last);

   // ECB encryptor, including key expansion
   ecbOut = aes_ecb128(stateIn.data.range(255,128), nonceCntOut);

   // xor ECB output with plaintext for encryptor or ciphertext for decryptor
   stateOut.data = stateIn.data.range(127,0) ^ ecbOut;

   
 }


