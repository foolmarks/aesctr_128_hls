/*-----------------------------------------------------------------
  File: aes_ecb128.cpp

  A complete AES-128  ECB mode encryptor, including key expansion.
  
  Ther are 10 rounds required for AES-128.
------------------------------------------------------------------*/



#include "aes128_ctr.h"



word128 aes_ecb128(word128 key, word128 stateIn)
{
	word128 stateVector0;
	word128 stateVector1;
	word128 stateVector2;
	word128 stateOut;
    word128 engineOut;
    word4   rConAddr = 0;
    word128 roundKey;

  
  ecb_loop0: for (unsigned int i = 0; i < 11; i++) {
    
    word128 mux1;
    word128 mux2;
    
    
    /*----------------------------------------
     ROUND KEY CALCULATION    
    -----------------------------------------*/
 	roundKey = (i == 0) ? key : engineOut;
    engineOut = keyExpEngine(rConAddr, roundKey);
    rConAddr++;   
    
    
    
    /*----------------------------------------
     ECB ENCRYPTION    
    -----------------------------------------*/     
    
    // mux in front of sub Bytes stage
    mux1 = (i == 0) ? stateIn : stateOut;
    
    
    // subBytes
    stateVector0 = subBytes(mux1);
    
    
    // shift rows
    stateVector1 = shiftRows(stateVector0);
    
    
    // mix columns
    stateVector2 = encMixCols(stateVector1);    
    
    
    // mux in front of add round key stage
    if (i == 0) {
	   mux2 = stateIn;
    } else if (i == 10) {
	   mux2 = stateVector1;
    } else {
	   mux2 = stateVector2;  }
     
     
    // add round key
    stateOut = mux2 ^ roundKey;
    
  }
  
  return stateOut;
  
}
  


