/*-----------------------------------------------------------------
  File: encMixCols.cpp

  Mix Columns function for AES encryption.

------------------------------------------------------------------*/


#include "aes128_ctr.h"

word128 encMixCols(word128 stateIn)
{
    
  word128 stateOut;
    
  stateOut.range(127,120) = gfmult2(stateIn.range(127,120)) ^ gfmult3(stateIn.range(119,112)) ^ stateIn.range(111,104)          ^ stateIn.range(103,96);
  stateOut.range(119,112) = stateIn.range(127,120)          ^ gfmult2(stateIn.range(119,112)) ^ gfmult3(stateIn.range(111,104)) ^ stateIn.range(103,96);
  stateOut.range(111,104) = stateIn.range(127,120)          ^ stateIn.range(119,112)          ^ gfmult2(stateIn.range(111,104)) ^ gfmult3(stateIn.range(103,96));
  stateOut.range(103,96)  = gfmult3(stateIn.range(127,120)) ^ stateIn.range(119,112)          ^ stateIn.range(111,104)          ^ gfmult2(stateIn.range(103,96));

  stateOut.range(95,88)   = gfmult2(stateIn.range(95,88))   ^ gfmult3(stateIn.range(87,80))   ^ stateIn.range(79,72)            ^ stateIn.range(71,64);
  stateOut.range(87,80)   = stateIn.range(95,88)            ^ gfmult2(stateIn.range(87,80))   ^ gfmult3(stateIn.range(79,72))   ^ stateIn.range(71,64);
  stateOut.range(79,72)   = stateIn.range(95,88)            ^ stateIn.range(87,80)            ^ gfmult2(stateIn.range(79,72))   ^ gfmult3(stateIn.range(71,64));
  stateOut.range(71,64)   = gfmult3(stateIn.range(95,88))   ^ stateIn.range(87,80)            ^ stateIn.range(79,72)            ^ gfmult2(stateIn.range(71,64));
                                                                                                                                                                                                                             
  stateOut.range(63,56)   = gfmult2(stateIn.range(63,56))   ^ gfmult3(stateIn.range(55,48))   ^ stateIn.range(47,40)            ^ stateIn.range(39,32);
  stateOut.range(55,48)   = stateIn.range(63,56)            ^ gfmult2(stateIn.range(55,48))   ^ gfmult3(stateIn.range(47,40))   ^ stateIn.range(39,32);
  stateOut.range(47,40)   = stateIn.range(63,56)            ^ stateIn.range(55,48)            ^ gfmult2(stateIn.range(47,40))   ^ gfmult3(stateIn.range(39,32));
  stateOut.range(39,32)   = gfmult3(stateIn.range(63,56))   ^ stateIn.range(55,48)            ^ stateIn.range(47,40)            ^ gfmult2(stateIn.range(39,32));
  
  stateOut.range(31,24)   = gfmult2(stateIn.range(31,24))   ^ gfmult3(stateIn.range(23,16))   ^ stateIn.range(15,8)             ^ stateIn.range(7,0);
  stateOut.range(23,16)   = stateIn.range(31,24)            ^ gfmult2(stateIn.range(23,16))   ^ gfmult3(stateIn.range(15,8))    ^ stateIn.range(7,0);
  stateOut.range(15,8)    = stateIn.range(31,24)            ^ stateIn.range(23,16)            ^ gfmult2(stateIn.range(15,8))    ^ gfmult3(stateIn.range(7,0));
  stateOut.range(7,0)     = gfmult3(stateIn.range(31,24))   ^ stateIn.range(23,16)            ^ stateIn.range(15,8)             ^ gfmult2(stateIn.range(7,0));
  
  return stateOut;

}

word8 gfmult2(word8 I)
{  
  ap_uint<1> xor_73;
  ap_uint<1> xor_72;
  ap_uint<1> xor_70;
  word8 result;
  
  xor_73 = I[7] ^ I[3];
  xor_72 = I[7] ^ I[2];
  xor_70 = I[7] ^ I[0];
  
  
  result = (I.range(6,4),xor_73,xor_72,I[1],xor_70,I[7]);
  
  return result;

}


word8 gfmult3(word8 I)
{
  word8 result;
  
  result = gfmult2(I) ^ I;
  
  return result;

}


    
    
    
