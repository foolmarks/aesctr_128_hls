/*-----------------------------------------------------------------
  File: keyExpEngine.cpp

  Calculates the next round key for AES key expansion
------------------------------------------------------------------*/


#include "aes128_ctr.h"


word128 keyExpEngine(word4 rConAddr, word128 keyState)
{
  word128 expKey;

  word32 rotWordOut;
  word32 subWordOut;
  word32 rConOut;
  
  
  // bytes 0:3
  rotWordOut = rotWord(keyState.range(31,0));
  subWordOut = subWord(rotWordOut);
  rConOut = rCon(rConAddr);
  
  expKey.range(127,96) = subWordOut ^ keyState.range(127,96) ^ rConOut;  
  

  // bytes 4:7
  expKey.range(95,64) = expKey.range(127,96) ^ keyState.range(95,64);
  
  // bytes 8:11
  expKey.range(63,32) = expKey.range(95,64) ^ keyState.range(63,32);

  // bytes 12:15
  expKey.range(31,0) = expKey.range(63,32) ^ keyState.range(31,0);



  return expKey;
   
}

