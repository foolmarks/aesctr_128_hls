/*-----------------------------------------------------------------
  File: nonceCount.cpp
  
  Nonce and counter for AES counter mode.
  
  Initialisation Vector will be loaded at power-on/reset or at first
  16byte word (message block) of new plaintext/ciphertext message.
  
  The last word of current plaintext/ciphertext message is indicated
  by "last".
  
  At the first word of a new message, the counter and nonce will 
  load from init_vect. This allows the counter to be started at a 
  non-zero value chosen by the user.
  
  The sizes (in bits) of the counter and nonce variables can be 
  modified but the sum of their lengths must be 128.
  
  COUNT_BITS + NONCE_BITS must be 128.
------------------------------------------------------------------*/

#include "aes128_ctr.h"


word128 nonceCount(word128 init_vect, ap_uint<1> last)
{

   word128 nonceCntOut;
   static bool firstBlkInt = true;
   
   // sizes of count & nonce must be 128bits total
   static ap_uint<COUNT_BITS> count = 0;
   static ap_uint<NONCE_BITS> nonce = 0;

   if (firstBlkInt == false && last == 0) {
	   count++;
   } else if (firstBlkInt == true && last == 0) {
	   count = init_vect.range(COUNT_BITS-1,0);
	   nonce = init_vect.range(NONCE_BITS+COUNT_BITS-1,COUNT_BITS);
	   firstBlkInt = false;
   } else if (firstBlkInt == false && last == 1) {
	   count++;
	   firstBlkInt = true;
   } else {
	   count = init_vect.range(COUNT_BITS-1,0);
	   nonce = init_vect.range(NONCE_BITS+COUNT_BITS-1,COUNT_BITS);
	   firstBlkInt = true;
   }
   

   nonceCntOut = (nonce,count);

   return nonceCntOut;
      
 }
