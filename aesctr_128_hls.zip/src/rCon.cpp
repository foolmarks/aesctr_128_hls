/*-----------------------------------------------------------------
  File: rCon.cpp
  
  RCON lookup table for AES key expansion
------------------------------------------------------------------*/

#include "aes128_ctr.h"



word32 rCon(word4 index)
{

	word32 rConVal;


    static word8 rConTable[16] = {
           0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
           0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x01 };   
    
    
    rConVal.range(31,24) = rConTable[index];
    rConVal.range(23,16) = 0x00;
    rConVal.range(15,8)  = 0x00;
    rConVal.range(7,0)   = 0x00;


    return rConVal;
       
}

