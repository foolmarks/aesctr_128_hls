/*-----------------------------------------------------------------
  File: rotWord.cpp
  
  Word rotate function for AES key expansion
------------------------------------------------------------------*/

#include "aes128_ctr.h"



word32 rotWord(word32 stateIn)
{
	word32 stateOut;

  stateOut.range(31,24)  = stateIn.range(23,16);
  stateOut.range(23,16)  = stateIn.range(15,8);
  stateOut.range(15,8)   = stateIn.range(7,0) ;
  stateOut.range(7,0)    = stateIn.range(31,24);

  return stateOut;
   
}
