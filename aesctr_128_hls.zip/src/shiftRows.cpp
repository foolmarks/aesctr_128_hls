/*-----------------------------------------------------------------
  File: shiftRows.cpp
  Row 0 - not shifted
  Row 1 - circular shift left by 1 byte
  Row 2 - circular shift left by 2 bytes
  Row 3 - circular shift left by 3 bytes
 
       State Vector In            State Vector Out
    ---------------------        ---------------------
    |  0 |  4 |  8 | 12 |        |  0 |  4 |  8 | 12 |
    ---------------------        ---------------------
    |  1 |  5 |  9 | 13 |        |  5 |  9 | 13 |  1 |
    ---------------------        ---------------------
    |  2 |  6 | 10 | 14 |        | 10 | 14 |  2 |  6 |
    ---------------------        ---------------------
    |  3 |  7 | 11 | 15 |        | 15 |  3 |  7 | 11 |
    ---------------------        ---------------------
 
   byte 0 of state vector maps to STATEIN(127:119)
   byte 15 of state vector maps to STATEIN(7:0)
------------------------------------------------------------------*/

#include "aes128_ctr.h"

word128 shiftRows(word128 stateIn)
{
    
  word128 stateOut;
  
    
  // row 0
  stateOut.range(127,120)   = stateIn.range(127,120);  // byte0  -> byte0
  stateOut.range(95,88)     = stateIn.range(95,88);    // byte4  -> byte4
  stateOut.range(63,56)     = stateIn.range(63,56);    // byte8  -> byte8
  stateOut.range(31,24)     = stateIn.range(31,24);    // byte12 -> byte12

  // row 1
  stateOut.range(119,112)   = stateIn.range(87,80);    // byte1  -> byte5
  stateOut.range(87,80)     = stateIn.range(55,48);    // byte5  -> byte9
  stateOut.range(55,48)     = stateIn.range(23,16);    // byte9  -> byte13
  stateOut.range(23,16)     = stateIn.range(119,112);  // byte13 -> byte1
  
  // row 2
  stateOut.range(111,104)   = stateIn.range(47,40);    // byte2  -> byte10
  stateOut.range(79,72)     = stateIn.range(15,8);     // byte6  -> byte14
  stateOut.range(47,40)     = stateIn.range(111,104);  // byte10 -> byte2
  stateOut.range(15,8)      = stateIn.range(79,72);    // byte14 -> byte6

  // row 3
  stateOut.range(103,96)   = stateIn.range(7,0);       // byte3  -> byte15
  stateOut.range(71,64)    = stateIn.range(103,96);    // byte7  -> byte3
  stateOut.range(39,32)    = stateIn.range(71,64);     // byte11 -> byte7
  stateOut.range(7,0)      = stateIn.range(39,32);     // byte15 -> byte11

  
  return stateOut;

}
