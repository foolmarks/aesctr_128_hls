/*-----------------------------------------------------------------
  File: subBytes.cpp
  
  AES SBOX Function
------------------------------------------------------------------*/

#include "aes128_ctr.h"

word128 subBytes(word128 stateIn)
{
	word128 stateOut;


	subBytes_label0:for (int i = 0; i < 16; i++){
		stateOut.range(i*8+7,i*8) = sBoxValue_16(i,stateIn.range(i*8+7,i*8));
	}


	return stateOut;

   
}
