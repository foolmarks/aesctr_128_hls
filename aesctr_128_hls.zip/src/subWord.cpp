/*-----------------------------------------------------------------
  File: subWord.cpp

  SBOX fucntion for key expansion
------------------------------------------------------------------*/


#include "aes128_ctr.h"


word32 subWord(word32 stateIn)
{
	word32 stateOut;


	subWord_label0:for (int i = 0; i < 4; i++){
		stateOut.range(i*8+7,i*8) = sBoxValue_4(i, stateIn.range(i*8+7,i*8));
	}

  return stateOut;
   
}
