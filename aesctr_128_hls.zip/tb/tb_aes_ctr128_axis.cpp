#include "../src/aes128_ctr.h"



int main() {



  string dummy0;
  string dummy1;

  string outFileName;

  word128 tbKey;
  word128 tbInitVect;
  word128 plainTextECB;
  word128 cipherTextECB;  
  word128 tbPlainText;

  string inFileName = "aes128_ctr.rsp";
  
  ap_uint<1> tbLast = 0;
  ap_axiu<384> tbStateIn;
  ap_axiu<128> tbStateOut;

  bool pass = true;

  word128 tbPlainTextArray[4];
  word128 tbExpResultsArray[4];


  // open KAT file & results file
  ifstream inData;
  ofstream outData;
  inData.open(inFileName.c_str());
  outFileName = inFileName + "_results.txt";
  outData.open(outFileName.c_str());
  
  
  // check file open worked ok
  if (!inData.is_open()) {
      cout << "Input file open failed" << endl;
      return 1; }
  if (!outData.is_open()) {
      cout << "Results file open failed" << endl;
      return 1; }
  
  cout << "Simulation started.." << endl;

  /*--------------------------------------------------------------
   FIRST TEST SENDS 4 VECTORS & KEY & INIT VECTOR FROM NIST
   TEST FILE
   --------------------------------------------------------------*/

  // get the key & Init Vector
  inData >> dummy0 >> hex >> tbKey;
  inData >> dummy0 >> dummy1 >> hex >> tbInitVect;
  outData << "Key " << hex << tbKey << endl;
  outData << "Init. Counter " << hex << tbInitVect << endl;

  cout << "------------------------------------------" << endl;
  cout << "Key: " << hex << tbKey << endl;
  cout << "Init. Counter " << hex << tbInitVect << endl;


  // write input data vectors and expected results into a pair of arrays
  for (int i = 0; i < 4; i++ ) {
      inData >> dummy0 >> dummy1 >> hex >> plainTextECB;      // throw away, not used
      inData >> dummy0 >> dummy1 >> hex >> cipherTextECB;     // throw away, not used
      inData >> dummy0 >> hex >> tbPlainTextArray[i];         // input unciphered text
      inData >> dummy0 >> hex >> tbExpResultsArray[i];        // expected "golden" output result
  }


  // apply input vector & check output results
  for (int i = 0; i < 4; i++ )	{

	  tbLast = (i==3) ? 1:0;

      outData << "Plaintext " << hex << tbPlainTextArray[i] << endl;

      tbStateIn.data.range(127,0) = tbPlainTextArray[i];
      tbStateIn.data.range(383,256) = tbInitVect;
      tbStateIn.data.range(255,128) = tbKey;
      tbStateIn.last = tbLast;

      // call function under test
      aes_ctr128_axis(tbStateIn, tbStateOut);

      outData << "Ciphertext " << hex << tbStateOut.data << endl;
      if (tbExpResultsArray[i] != tbStateOut.data) {
    	  pass = false;
    	  cout << "FAIL! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      } else {
    	  cout << "PASS! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      }
    }


  /*--------------------------------------------------------------
   RUN SAME TEST GAIN TO ENSURE THAT INIT VECTOR IS CORRECTLY
   RELOADED AT END OF MESSAGE
   --------------------------------------------------------------*/


  cout << "------------------------------------------" << endl;
  cout << "Key: " << hex << tbKey << endl;
  cout << "Init. Counter " << hex << tbInitVect << endl;



  for (int i = 0; i < 4; i++ )	{

	  tbLast = (i==3) ? 1:0;

      outData << "Plaintext " << hex << tbPlainTextArray[i] << endl;

      tbStateIn.data.range(127,0) = tbPlainTextArray[i];
      tbStateIn.data.range(383,256) = tbInitVect;
      tbStateIn.data.range(255,128) = tbKey;
      tbStateIn.last = tbLast;

      // call function under test
      aes_ctr128_axis(tbStateIn, tbStateOut);


      outData << "Ciphertext " << hex << tbStateOut.data << endl;
      if (tbExpResultsArray[i] != tbStateOut.data) {
    	  pass = false;
    	  cout << "FAIL! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      } else {
    	  cout << "PASS! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      }
  }


  /*--------------------------------------------------------------
   ANOTHER TEST WITH A DIFFERENT SET OF INPUTS, KEY & INIT VECTOR
   NOT NIST STANDARD
   --------------------------------------------------------------*/

  // get new key & Init Vector
  inData >> dummy0 >> hex >> tbKey;
  inData >> dummy0 >> dummy1 >> hex >> tbInitVect;
  outData << "Key " << hex << tbKey << endl;
  outData << "Init. Counter " << hex << tbInitVect << endl;

  cout << "------------------------------------------" << endl;
  cout << "Key: " << hex << tbKey << endl;
  cout << "Init. Counter " << hex << tbInitVect << endl;


  // write input data vectors and expected results into a pair of arrays
  for (int i = 0; i < 4; i++ ) {
      inData >> dummy0 >> dummy1 >> hex >> plainTextECB;      // throw away, not used
      inData >> dummy0 >> dummy1 >> hex >> cipherTextECB;     // throw away, not used
      inData >> dummy0 >> hex >> tbPlainTextArray[i];         // input unciphered text
      inData >> dummy0 >> hex >> tbExpResultsArray[i];        // expected "golden" output result
  }


  // apply input vector & check output results
  for (int i = 0; i < 4; i++ )	{

	  tbLast = (i==3) ? 1:0;

      outData << "Plaintext " << hex << tbPlainTextArray[i] << endl;

      tbStateIn.data.range(127,0) = tbPlainTextArray[i];
      tbStateIn.data.range(383,256) = tbInitVect;
      tbStateIn.data.range(255,128) = tbKey;
      tbStateIn.last = tbLast;

      // call function under test
      aes_ctr128_axis(tbStateIn, tbStateOut);

      outData << "Ciphertext " << hex << tbStateOut.data << endl;
      if (tbExpResultsArray[i] != tbStateOut.data) {
    	  pass = false;
    	  cout << "FAIL! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      } else {
    	  cout << "PASS! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      }
    }


  tbLast = 0;


  /*--------------------------------------------------------------
   TLAST IS HELD AT 1 TO TEST A RUN OF MESSAGES MADE UP OF SINGLE
   128BIT BLOCKS
   --------------------------------------------------------------*/

  // get new key & Init Vector
  inData >> dummy0 >> hex >> tbKey;
  inData >> dummy0 >> dummy1 >> hex >> tbInitVect;
  outData << "Key " << hex << tbKey << endl;
  outData << "Init. Counter " << hex << tbInitVect << endl;

  cout << "------------------------------------------" << endl;
  cout << "Key: " << hex << tbKey << endl;
  cout << "Init. Counter " << hex << tbInitVect << endl;


  // write input data vectors and expected results into a pair of arrays
  for (int i = 0; i < 4; i++ ) {
      inData >> dummy0 >> dummy1 >> hex >> plainTextECB;      // throw away, not used
      inData >> dummy0 >> dummy1 >> hex >> cipherTextECB;     // throw away, not used
      inData >> dummy0 >> hex >> tbPlainTextArray[i];         // input unciphered text
      inData >> dummy0 >> hex >> tbExpResultsArray[i];        // expected "golden" output result
  }

  for (int i = 0; i < 4; i++ )	{

	  tbLast = 1;

      outData << "Plaintext " << hex << tbPlainTextArray[i] << endl;

      tbStateIn.data.range(127,0) = tbPlainTextArray[i];
      tbStateIn.data.range(383,256) = tbInitVect;
      tbStateIn.data.range(255,128) = tbKey;
      tbStateIn.last = tbLast;

      // call function under test
      aes_ctr128_axis(tbStateIn, tbStateOut);

      outData << "Ciphertext " << hex << tbStateOut.data << endl;
      if (tbExpResultsArray[i] != tbStateOut.data) {
    	  pass = false;
    	  cout << "FAIL! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      } else {
    	  cout << "PASS! Input: " << hex << tbStateIn.data.range(127,0) << "  Output: " << hex << tbStateOut.data << "  Expected: " << hex << tbExpResultsArray[i] << "  Last: " << dec << tbStateOut.last << endl;
      }
    }




  // close files
  outData.close();
  inData.close();



  if (pass == true)
    {cout << "TEST PASSED" << endl; }
  else
    {cout << "TEST FAILED" << endl; }


  cout << "Simulation finished" << endl;

  return 0;

}



